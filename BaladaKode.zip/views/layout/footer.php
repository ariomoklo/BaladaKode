
       <!-- Footer -->
    <footer style="z-index: 2;">
        <div class="bordering" style="background-color: #4e565e"></div>
        <div class="row">
            <div class="col-lg-12">
                <p class="copy">Copyright &copy; Code Ballad 2014</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo ASSETS;?>js/bootstrap.min.js"></script>
    <script src="<?php echo ASSETS;?>codemirror/codemirror.js"></script>
    <script src="<?php echo ASSETS;?>js/routing.js"></script>
</body>
</html>