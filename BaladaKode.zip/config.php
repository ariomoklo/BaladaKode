<?php

// Code Ballad Configuration File

//Configure Default Controller
Config::set('DEFAULT_ROUTE', 'main');


// Configure Default Action
Config::set('DEFAULT_ACTION', 'index');

// Configure Data Base
Config::set('DB.HOST', 'mysql.idhostinger.com');
Config::set('DB.USER', 'u835915073_ario');
Config::set('DB.PASSWORD', 'QWE123!@#');
Config::set('DB.NAME', 'u835915073_cb');